module.exports =  {
    "semi": true,
    "singleQuote": true,
    "tabWidth": 4,
    "useTabs": false,
    "printWidth": 120
};