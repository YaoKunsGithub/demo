export default {
    dbPath: 'mongodb://localhost:27017'
};
