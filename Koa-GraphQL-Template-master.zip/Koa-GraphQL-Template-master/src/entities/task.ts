import { prop, getModelForClass } from '@typegoose/typegoose';
import { Field, ObjectType } from 'type-graphql';

// @pre<Task>('save', function() {
//     // 直接this.meta.xxx赋值会不生效
//     if (this.isNew) {
//         this.meta.createdAt = this.updatedAt = Date.now();
//     } else {
//         this.meta.updatedAt = Date.now();
//     }
// })
@ObjectType()
export class Task {
    @Field({ description: 'id' })
    public _id: string;

    @Field({ description: '标题' })
    @prop()
    public name!: string;

    @Field({ description: '内容' })
    @prop()
    public content!: string;

    // 1 - 完成
    // 2 - 超时
    // 3 - 未完成
    // 4 - 删除
    @Field({ description: '状态' })
    @prop()
    public status!: number;

    @Field({ description: '创建时间' })
    @prop({ default: Date.now() })
    public createdAt!: number;

    @Field({ description: '更新时间' })
    @prop({ default: Date.now() })
    public updatedAt!: number;

    // @Field({ description: '父任务', nullable: true })
    // @prop({ ref: Task })
    // public parent!: Task;
}

export const TaskModel = getModelForClass(Task);
