import path from 'path';
import Koa from 'koa';
import { ApolloServer } from 'apollo-server-koa';
import { buildSchema } from 'type-graphql';

const getResolvers = () => {
    return [path.resolve(__dirname + '/resolvers/*.ts')];
};

const getSchema = async () => {
    try {
        return buildSchema({
            resolvers: getResolvers()
        });
    } catch (error) {
        console.log(error);
    }
};

export async function integrateGraphql(app: Koa<Koa.DefaultState, Koa.DefaultContext>) {
    try {
        const server = new ApolloServer({
            schema: await getSchema(),
            playground: {
                settings: {
                    'request.credentials': 'include'
                }
            } as any,
            introspection: true,
            context: ({ ctx }) => ctx
        });
        server.applyMiddleware({ app });
        return server;
    } catch (error) {
        console.log(error);
    }
}
