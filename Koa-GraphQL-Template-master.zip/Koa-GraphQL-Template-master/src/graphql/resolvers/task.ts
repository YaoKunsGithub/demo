import { Resolver, Mutation, Arg, InputType, Field, Query } from 'type-graphql';
import { Task, TaskModel } from '../../entities/task';

@InputType()
class CreateTaskInput {
    @Field({ description: '标题', nullable: false })
    public name!: string;

    @Field({ description: '内容', nullable: false })
    public content!: string;

    // @Field({ description: '父任务', nullable: true })
    // public parentId!: string;
}

@InputType()
class UpdateTaskInput {
    @Field({ description: 'id', nullable: false })
    public _id!: string;

    @Field({ description: '标题', nullable: true })
    public name!: string;

    @Field({ description: '内容', nullable: true })
    public content: string;

    @Field({ description: '状态', nullable: true })
    public status?: number;
}
@InputType()
class CompleteTaskInput {
    @Field({ description: 'id', nullable: false })
    public _id!: string;

    @Field({ description: '状态', nullable: true })
    public status?: number;
}
@InputType()
class OvertimeTaskInput {
    @Field({ description: 'id', nullable: false })
    public _id!: string;

    @Field({ description: '状态', nullable: true })
    public status?: number;
}

@Resolver(Task)
export class TaskResolver {
    //查询
    @Query(() => Task, { name: 'task' })
    async findOneTaskById(@Arg('id') id: string) {
        const task = (await TaskModel.findById(id)).toJSON();

        return task;
    }
    //新增
    @Mutation(() => Task)
    async createTask(@Arg('input') newTask: CreateTaskInput) {
        const task = await TaskModel.create({ ...newTask, status: 3 });
        return task.toJSON();
    }
    //修改
    @Mutation(() => Task)
    async updateTask(@Arg('input') updateTask: UpdateTaskInput) {
        const { _id, ...rest } = updateTask;
        await TaskModel.updateOne({ _id: updateTask._id }, { ...rest }).exec();
        return (await TaskModel.findById(_id)).toJSON();
    }
    //置完成
    @Mutation(() => Task)
    async completeTask(@Arg('input') completeTask: CompleteTaskInput) {
        const { _id } = completeTask;
        await TaskModel.updateOne({ _id: completeTask._id }, { status: 1 }).exec();
        return (await TaskModel.findById(_id)).toJSON();
    }
    //置超时
    @Mutation(() => Task)
    async overtimeTask(@Arg('input') overtimeTask: OvertimeTaskInput) {
        const { _id } = overtimeTask;
        await TaskModel.updateOne({ _id: overtimeTask._id }, { status: 4 }).exec();
        return (await TaskModel.findById(_id)).toJSON();
    }
}
