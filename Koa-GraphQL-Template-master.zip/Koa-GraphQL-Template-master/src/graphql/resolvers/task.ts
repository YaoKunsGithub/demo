import { Resolver, Mutation, Arg, InputType, Field, Query } from 'type-graphql';
import { Task, TaskModel } from '../../entities/task';

@InputType()
class CreateTaskInput {
    @Field({ description: '标题', nullable: false })
    public name!: string;

    @Field({ description: '内容', nullable: false })
    public content!: string;

    // @Field({ description: '父任务', nullable: true })
    // public parentId!: string;
}

@InputType()
class UpdateTaskInput {
    @Field({ description: 'id', nullable: false })
    public _id!: string;

    @Field({ description: '标题', nullable: true })
    public name!: string;

    @Field({ description: '内容', nullable: true })
    public content: string;

    @Field({ description: '状态', nullable: true })
    public status?: number;
}

@Resolver(Task)
export class TaskResolver {
    @Query(() => Task, { name: 'task' })
    async findOneTaskById(@Arg('id') id: string) {
        const task = (await TaskModel.findById(id)).toJSON();

        return task;
    }

    @Mutation(() => Task)
    async createTask(@Arg('input') newTask: CreateTaskInput) {
        const task = await TaskModel.create({ ...newTask, status: 3 });
        return task.toJSON();
    }

    @Mutation(() => Task)
    async updateTask(@Arg('input') updateTask: UpdateTaskInput) {
        const { _id, ...rest } = updateTask;
        await TaskModel.updateOne({ _id: updateTask._id }, { ...rest }).exec();
        return (await TaskModel.findById(_id)).toJSON();
    }
}
